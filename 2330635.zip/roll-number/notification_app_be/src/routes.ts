import { Router, Request, Response } from "express";
import { log } from "logging_middleware";
import { sendNotification, listNotifications, getNotification, removeNotification } from "./service";
import { CreateNotificationDTO } from "./types";

const router = Router();

// POST /notifications — create & dispatch a notification
router.post("/", async (req: Request, res: Response) => {
  await log("backend", "info", "handler", "POST /notifications received");
  const dto = req.body as CreateNotificationDTO;

  if (!dto.title || !dto.body || !dto.category || !dto.targetAudience) {
    await log("backend", "warn", "handler", "Missing required fields in notification payload");
    return res.status(400).json({ success: false, error: "Missing required fields" });
  }

  try {
    const notification = await sendNotification(dto);
    return res.status(201).json({ success: true, data: notification });
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    await log("backend", "error", "handler", `Failed to create notification: ${errMsg}`);
    return res.status(500).json({ success: false, error: errMsg });
  }
});

// GET /notifications — list all notifications
router.get("/", async (_req: Request, res: Response) => {
  await log("backend", "info", "handler", "GET /notifications received");
  const notifications = await listNotifications();
  return res.json({ success: true, data: notifications });
});

// GET /notifications/:id — get single notification
router.get("/:id", async (req: Request, res: Response) => {
  await log("backend", "info", "handler", `GET /notifications/${req.params.id} received`);
  const notification = await getNotification(req.params.id);
  if (!notification) {
    return res.status(404).json({ success: false, error: "Notification not found" });
  }
  return res.json({ success: true, data: notification });
});

// DELETE /notifications/:id
router.delete("/:id", async (req: Request, res: Response) => {
  await log("backend", "info", "handler", `DELETE /notifications/${req.params.id} received`);
  const deleted = await removeNotification(req.params.id);
  if (!deleted) {
    return res.status(404).json({ success: false, error: "Notification not found" });
  }
  return res.json({ success: true, message: "Notification deleted" });
});

export default router;
