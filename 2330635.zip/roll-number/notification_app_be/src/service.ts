import { log } from "logging_middleware";
import { CreateNotificationDTO, Notification } from "./types";
import {
  createNotification,
  getAllNotifications,
  getNotificationById,
  deleteNotification,
} from "./repository";

export async function sendNotification(dto: CreateNotificationDTO): Promise<Notification> {
  await log("backend", "info", "service", `Sending notification: ${dto.title}`);
  const notification = await createNotification(dto);
  await log("backend", "info", "service", `Notification dispatched id=${notification.id}`);
  return notification;
}

export async function listNotifications(): Promise<Notification[]> {
  return getAllNotifications();
}

export async function getNotification(id: string): Promise<Notification | null> {
  const notification = await getNotificationById(id);
  if (!notification) {
    await log("backend", "warn", "service", `Notification not found id=${id}`);
  }
  return notification;
}

export async function removeNotification(id: string): Promise<boolean> {
  return deleteNotification(id);
}
