export type NotificationCategory = "academic" | "event" | "emergency" | "general";

export interface Notification {
  id: string;
  title: string;
  body: string;
  category: NotificationCategory;
  targetAudience: string[];   // e.g. ["all"] | ["students"] | ["staff"]
  createdAt: string;          // ISO timestamp
}

export interface CreateNotificationDTO {
  title: string;
  body: string;
  category: NotificationCategory;
  targetAudience: string[];
}
