import { Notification, CreateNotificationDTO } from "./types";
import { log } from "logging_middleware";

// In-memory store (no database per spec)
const store: Map<string, Notification> = new Map();
let counter = 1;

export async function createNotification(
  dto: CreateNotificationDTO
): Promise<Notification> {
  const notification: Notification = {
    id: `notif-${counter++}`,
    ...dto,
    createdAt: new Date().toISOString(),
  };
  store.set(notification.id, notification);
  await log("backend", "info", "repository", `Created notification id=${notification.id}`);
  return notification;
}

export async function getAllNotifications(): Promise<Notification[]> {
  await log("backend", "debug", "repository", "Fetching all notifications");
  return Array.from(store.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export async function getNotificationById(id: string): Promise<Notification | null> {
  await log("backend", "debug", "repository", `Fetching notification id=${id}`);
  return store.get(id) ?? null;
}

export async function deleteNotification(id: string): Promise<boolean> {
  const deleted = store.delete(id);
  await log(
    "backend",
    deleted ? "info" : "warn",
    "repository",
    deleted ? `Deleted notification id=${id}` : `Notification id=${id} not found for deletion`
  );
  return deleted;
}
