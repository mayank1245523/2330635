import express from "express";
import { log } from "logging_middleware";
import notificationRoutes from "./routes";

const app = express();
const PORT = process.env.PORT || 3002;

app.use(express.json());

// Attach routes
app.use("/notifications", notificationRoutes);

// Health check
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "notification_app_be" });
});

app.listen(PORT, async () => {
  await log("backend", "info", "config", `notification_app_be running on port ${PORT}`);
  console.log(`[notification_app_be] Server started on port ${PORT}`);
});

export default app;
