import axios from "axios";

const LOG_API_URL = "http://4.224.186.213/evaluation-service/logs";

// Bearer token for authentication — replace with actual token if provided
const AUTH_TOKEN = process.env.AUTH_TOKEN || "your-auth-token-here";

type Stack = "backend" | "frontend";
type Level = "debug" | "info" | "warn" | "error" | "fatal";
type BackendPackage =
  | "cache"
  | "controller"
  | "cron_job"
  | "db"
  | "domain"
  | "handler"
  | "repository"
  | "route"
  | "service"
  | "auth"
  | "config"
  | "middleware"
  | "utils";

const VALID_STACKS: Stack[] = ["backend", "frontend"];
const VALID_LEVELS: Level[] = ["debug", "info", "warn", "error", "fatal"];
const VALID_BACKEND_PACKAGES: BackendPackage[] = [
  "cache",
  "controller",
  "cron_job",
  "db",
  "domain",
  "handler",
  "repository",
  "route",
  "service",
  "auth",
  "config",
  "middleware",
  "utils",
];

function validate(stack: string, level: string, pkg: string): void {
  if (!VALID_STACKS.includes(stack as Stack)) {
    throw new Error(
      `Invalid stack "${stack}". Must be one of: ${VALID_STACKS.join(", ")}`
    );
  }
  if (!VALID_LEVELS.includes(level as Level)) {
    throw new Error(
      `Invalid level "${level}". Must be one of: ${VALID_LEVELS.join(", ")}`
    );
  }
  if (stack === "backend" && !VALID_BACKEND_PACKAGES.includes(pkg as BackendPackage)) {
    throw new Error(
      `Invalid package "${pkg}" for backend stack. Must be one of: ${VALID_BACKEND_PACKAGES.join(", ")}`
    );
  }
}

export async function log(
  stack: string,
  level: string,
  pkg: string,
  message: string
): Promise<void> {
  // Enforce lowercase
  const normalizedStack = stack.toLowerCase();
  const normalizedLevel = level.toLowerCase();
  const normalizedPackage = pkg.toLowerCase();

  validate(normalizedStack, normalizedLevel, normalizedPackage);

  const payload = {
    stack: normalizedStack,
    level: normalizedLevel,
    package: normalizedPackage,
    message,
  };

  try {
    await axios.post(LOG_API_URL, payload, {
      headers: {
        Authorization: `Bearer ${AUTH_TOKEN}`,
        "Content-Type": "application/json",
      },
    });
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    // Fail silently in production but surface errors in development
    if (process.env.NODE_ENV !== "production") {
      console.error(`[logging_middleware] Failed to send log: ${errMsg}`);
    }
  }
}
