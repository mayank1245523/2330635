import express, { Request, Response } from "express";
import { log } from "logging_middleware";
import { runScheduler } from "./scheduler";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

// Health check
app.get("/health", (_req: Request, res: Response) => {
  res.json({ status: "ok", service: "vehicle_maintence_scheduler" });
});

// Trigger optimization
app.get("/schedule", async (_req: Request, res: Response) => {
  await log("backend", "info", "handler", "Received request to /schedule");
  try {
    const results = await runScheduler();
    res.json({ success: true, data: results });
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    await log("backend", "error", "handler", `Schedule endpoint failed: ${errMsg}`);
    res.status(500).json({ success: false, error: errMsg });
  }
});

app.listen(PORT, async () => {
  await log("backend", "info", "config", `vehicle_maintence_scheduler running on port ${PORT}`);
  console.log(`[vehicle_maintence_scheduler] Server started on port ${PORT}`);
});

export default app;
