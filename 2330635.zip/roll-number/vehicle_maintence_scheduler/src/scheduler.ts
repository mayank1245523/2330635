import { log } from "logging_middleware";
import { fetchDepots, fetchVehicles } from "./apiClient";
import { knapsack } from "./knapsack";
import { ScheduleResult } from "./types";

export async function runScheduler(): Promise<ScheduleResult[]> {
  await log("backend", "info", "service", "Vehicle maintenance scheduler started");

  const [depots, vehicles] = await Promise.all([fetchDepots(), fetchVehicles()]);

  await log(
    "backend",
    "debug",
    "service",
    `Processing ${depots.length} depots with ${vehicles.length} available tasks`
  );

  const results: ScheduleResult[] = [];

  for (const depot of depots) {
    await log(
      "backend",
      "debug",
      "service",
      `Running knapsack for depot ${depot.ID} with capacity ${depot.MechanicHours} hours`
    );

    const selectedTasks = knapsack(vehicles, depot.MechanicHours);
    const totalDuration = selectedTasks.reduce((sum, t) => sum + t.Duration, 0);
    const totalImpact = selectedTasks.reduce((sum, t) => sum + t.Impact, 0);

    const result: ScheduleResult = {
      depotId: depot.ID,
      mechanicHoursCapacity: depot.MechanicHours,
      selectedTasks,
      totalDuration,
      totalImpact,
    };

    results.push(result);

    await log(
      "backend",
      "info",
      "service",
      `Depot ${depot.ID}: selected ${selectedTasks.length} tasks, impact=${totalImpact}, duration=${totalDuration}/${depot.MechanicHours}`
    );
  }

  await log("backend", "info", "service", "Scheduler completed successfully");
  return results;
}
