import { Vehicle } from "./types";

/**
 * Solves the 0/1 Knapsack problem to find the optimal subset of maintenance tasks.
 * @param tasks   Array of available tasks (each has Duration as weight, Impact as value)
 * @param capacity  Maximum mechanic hours available (knapsack capacity)
 * @returns The optimal subset of tasks
 */
export function knapsack(tasks: Vehicle[], capacity: number): Vehicle[] {
  const n = tasks.length;

  // dp[i][w] = max impact using first i items with capacity w
  const dp: number[][] = Array.from({ length: n + 1 }, () =>
    new Array(capacity + 1).fill(0)
  );

  for (let i = 1; i <= n; i++) {
    const task = tasks[i - 1];
    for (let w = 0; w <= capacity; w++) {
      // Don't include this task
      dp[i][w] = dp[i - 1][w];
      // Include this task if it fits
      if (task.Duration <= w) {
        const withTask = dp[i - 1][w - task.Duration] + task.Impact;
        if (withTask > dp[i][w]) {
          dp[i][w] = withTask;
        }
      }
    }
  }

  // Backtrack to find which tasks were selected
  const selectedTasks: Vehicle[] = [];
  let w = capacity;
  for (let i = n; i > 0; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      selectedTasks.push(tasks[i - 1]);
      w -= tasks[i - 1].Duration;
    }
  }

  return selectedTasks;
}
