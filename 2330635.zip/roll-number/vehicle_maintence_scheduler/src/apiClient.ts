import axios from "axios";
import { Depot, Vehicle } from "./types";
import { log } from "logging_middleware";

const BASE_URL = "http://4.224.186.213/evaluation-service";
const AUTH_TOKEN = process.env.AUTH_TOKEN || "your-auth-token-here";

const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    Authorization: `Bearer ${AUTH_TOKEN}`,
    "Content-Type": "application/json",
  },
});

export async function fetchDepots(): Promise<Depot[]> {
  await log("backend", "info", "service", "Fetching depots from evaluation service");
  try {
    const response = await apiClient.get<Depot[]>("/depots");
    await log("backend", "info", "service", `Fetched ${response.data.length} depots`);
    return response.data;
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    await log("backend", "error", "service", `Failed to fetch depots: ${errMsg}`);
    throw error;
  }
}

export async function fetchVehicles(): Promise<Vehicle[]> {
  await log("backend", "info", "service", "Fetching vehicles/tasks from evaluation service");
  try {
    const response = await apiClient.get<Vehicle[]>("/vehicles");
    await log("backend", "info", "service", `Fetched ${response.data.length} vehicle tasks`);
    return response.data;
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    await log("backend", "error", "service", `Failed to fetch vehicles: ${errMsg}`);
    throw error;
  }
}
