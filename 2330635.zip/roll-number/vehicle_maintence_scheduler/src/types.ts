export interface Depot {
  ID: string;
  MechanicHours: number;
}

export interface Vehicle {
  TaskId: string;
  Duration: number;
  Impact: number;
}

export interface ScheduleResult {
  depotId: string;
  mechanicHoursCapacity: number;
  selectedTasks: Vehicle[];
  totalDuration: number;
  totalImpact: number;
}
